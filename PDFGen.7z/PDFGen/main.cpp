﻿
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include "hpdfgen.h"


int main() {
	/*Create*/
	struct pdf_info pdf_info_data;
	strncpy(pdf_info_data.author, "My software", 64 - 1);
	strncpy(pdf_info_data.producer, "My software", 64 - 1);
	strncpy(pdf_info_data.title, "My document", 64 - 1);
	strncpy(pdf_info_data.subject, "My subject", 64 - 1);
	strncpy(pdf_info_data.date, "Today", 64 - 1);

	struct pdf_doc *pdf = pdf_create(PDF_A4_WIDTH, PDF_A4_HEIGHT, &pdf_info_data);
	pdf_set_font(pdf, "Times-Roman");
	pdf_append_page(pdf);
	int lineHeight = 20, padding = 20;

	/*Read*/
	std::ifstream myfile;
	std::string line; 
	myfile.open("input.txt");
	if (myfile.is_open()) {
		while (std::getline(myfile, line))
		{
			std::size_t found = line.find("+");
			std::cout << line << "aa:" << found << '\n';
			if (line.find("+") == 1) {
				pdf_add_text(pdf, NULL, line.c_str(), 13, padding, PDF_A4_HEIGHT - lineHeight, PDF_BLACK);
			}else if(line.find("|") == 1) {
				pdf_add_text(pdf, NULL, " |", 12, padding + 10, PDF_A4_HEIGHT - lineHeight - 10, PDF_BLACK);
				pdf_add_text(pdf, NULL, line.c_str(), 12, padding + 10, PDF_A4_HEIGHT - lineHeight, PDF_BLACK);
			} else {
				pdf_add_text(pdf, NULL, line.c_str(), 12, padding, PDF_A4_HEIGHT - lineHeight, PDF_BLACK);
			}
			lineHeight += 20; 
		}
		myfile.close();
	}

	/*Write*/
	//pdf_add_line(pdf, NULL, 50, 24, 150, 24, 3, PDF_BLACK);
	pdf_save(pdf, "output3.pdf");
	pdf_destroy(pdf);

	while (true)
	{
		if (getchar())break;
	}
	return 0;
}

