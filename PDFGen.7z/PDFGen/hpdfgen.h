#pragma once
#ifdef __cplusplus
extern "C" {
#endif
#include "pdfgen.h"

#ifdef __cplusplus
}
#endif

